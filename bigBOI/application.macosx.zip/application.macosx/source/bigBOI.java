import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 
import ddf.minim.ugens.*; 
import ddf.minim.analysis.*; 
import ddf.minim.effects.*; 
import ddf.minim.signals.*; 
import ddf.minim.spi.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class bigBOI extends PApplet {









MyAudioSocket mySocket;
int SWOTCH, SWOTCHING;

Minim             context;
AudioInput        in;
AudioOutput       out;
//ED

EnvelopeFollower  envFol;
FFT         fft;



//AKHIL
AudioPlayer akSong;
akAv akhilAV;
float spread;

Particle bass;
Particle[] mid;
Particle hi;

//BECKY
AudioPlayer song;
BeatDetect beat;
FFT fftB;
int bands = 2048;


float midB;

float summed=10;
float smoothScale = 0.05f;
int elements = 1000;
float spacing = TWO_PI/elements;
float sum[] = new float[bands];
int co = 1;
//int magnify = 37;
int magnify = 40;

int[] r = new int[co];
int[] g = new int[co];
int[] b = new int[co];
int[] amp1 = new int[co];
int[] amp2 = new int[co];



int[] r2 = new int[co];
int[] g2 = new int[co];
int[] b2 = new int[co];
int[] amp3 = new int[co];
int[] amp4 = new int[co];


int[] r3 = new int[co];
int[] g3 = new int[co];
int[] b3 = new int[co];
int[] amp5 = new int[co];
int[] amp6 = new int[co];

int[] r4 = new int[co];
int[] g4 = new int[co];
int[] b4 = new int[co];
int[] amp7 = new int[co];
int[] amp8 = new int[co];


int[] r5 = new int[co];
int[] g5 = new int[co];
int[] b5 = new int[co];
int[] amp9 = new int[co];
int[] amp10 = new int[co];


float backR, backG, backB;

float adder = 10;

int scaleX1;
int scaleY1;
int scaleX2;
int scaleY2;

float angle;

//SEB 
  Audio audio = new Audio(); 
  Output output;
  EnvelopeFollower envFollow;
  Sampler sampler;
 
//Akhil
FFT fftA;

//important frequencies of various instruments in song
float beepF = 1162.793f;
float clapF = 1874.9219f;
float kickF = 129.19922f;
float sawF = 2024.1211f;
float snareF = 9087.012f;
float breathF = 2885.4492f;
float saw1F = 516.797f;

//beat objects that detect if amplitude of a certain band is above a threshhold
akAvBeat beepB;
akAvBeat clapB;
akAvBeat saw1B;
akAvBeat kickB;
akAvBeat sawB;


//drawing objects
float c = 0;

int dim = 100; //the dimensions of the grid
int s = 1680/dim; //the size of each square in grid
float h = 0; //the multiplier for the noise 

public void setup()
{
  noCursor();
 // size(1280, 800, P3D);
//  size(1280, 1280, P3D);
  //frameRate(60);
   
  
  SWOTCH = 0;
  context = new Minim(this);
  
  in = context.getLineIn(Minim.MONO, 1024, 44100);
 // in.setGain(10); 
  in.disableMonitoring();
  out = context.getLineOut();
 
  //ED
  // Create the socket to connect input to output
  mySocket = new MyAudioSocket(1024);
  // Connect the socket as a "listener" for the line-in
  in.addListener(mySocket);
  //patch directly out, but you can patch into another UGen first
 // mySocket.patch(out);
  

  envFol = new EnvelopeFollower(0.0f, 0.1f, 1024);

  fft = new FFT( 1024, 44100 );
  fft.logAverages( 11, 1); //


  Sink sink = new Sink();
 
  fft.forward(in.mix);
 // sampler.patch( envFol ).patch( sink ).patch( out );
  mySocket.patch( envFol ).patch( sink ).patch( out );
  //sampler.trigger();




  bass = new Particle(height/2, -1);
  hi = new Particle(height, 1);
  mid = new Particle[8];
  for ( int i = 0; i < mid.length; i++) {
  mid[i] = new Particle(height/7, 1);
  }
  
 //BECKY
  
  // a beat detection object song SOUND_ENERGY mode with a sensitivity of 10 milliseconds
  beat = new BeatDetect();
  beat.detectMode(1);

  beat.setSensitivity(1);
  fftB = new FFT(in.bufferSize(), in.sampleRate());

  for (int i = 0; i < co; i++) {
    amp1[i] = PApplet.parseInt(random(1, 40));
    amp2[i] = PApplet.parseInt(random(1, 40));
    r[i] = PApplet.parseInt(random(0, 255));
    g[i] = PApplet.parseInt(random(0, 255));
    b[i] = PApplet.parseInt(random(0, 255));



    amp3[i] = PApplet.parseInt(random(1, 40));
    amp4[i] = PApplet.parseInt(random(1, 40));
    r2[i] = PApplet.parseInt(random(10, 255));
    g2[i] = PApplet.parseInt(random(10, 255));
    b2[i] = PApplet.parseInt(random(10, 255));

    amp5[i] = PApplet.parseInt(random(1, 40));
    amp6[i] = PApplet.parseInt(random(1, 40));
    r3[i] = PApplet.parseInt(random(10, 255));
    g3[i] = PApplet.parseInt(random(10, 255));
    b3[i] = PApplet.parseInt(random(10, 255));


    amp7[i] = PApplet.parseInt(random(1, 40));
    amp8[i] = PApplet.parseInt(random(1, 40));
    r4[i] = PApplet.parseInt(random(10, 255));
    g4[i] = PApplet.parseInt(random(10, 255));
    b4[i] = PApplet.parseInt(random(10, 255));


    amp9[i] = PApplet.parseInt(random(1, 40));
    amp10[i] = PApplet.parseInt(random(1, 40));
    r5[i] = PApplet.parseInt(random(10, 255));
    g5[i] = PApplet.parseInt(random(10, 255));
    b5[i] = PApplet.parseInt(random(10, 255));
  }

  scaleX1 = PApplet.parseInt(random(-150, 150));
  scaleY1 = PApplet.parseInt(random(-50, 10));
  scaleX2 = PApplet.parseInt(random(-150, 150));
  scaleY2 = PApplet.parseInt(random(-50, 50));
  
  //SEB
   output = new Output();
   envFollow = new EnvelopeFollower(0.0f, 0.1f, out.bufferSize()  ); //Envelope follower for tracking amplitude of the song
   // Sink sinkS = new Sink();
  
  output.initialise();
   mySocket.patch( envFollow ).patch( sink ).patch( out );
 // sampler = new Sampler(output.filename, 1, context); //loading song file
 // sampler.patch(envFollow).patch(sink).patch(out);
 // sampler.trigger();
  //sampler.patch(out);  
  
  
  
  //AKHIL
  //song = context.loadFile("500.mp3", 1024);

  //song.play();

  fftA = new FFT(in.bufferSize(), in.sampleRate());

  noStroke();
  
  //initalizing all the objects to detect various instruments in song
  beepB = new akAvBeat(beepF, 40, 500); 
  clapB = new akAvBeat(clapF, 5, 10);
  saw1B = new akAvBeat(saw1F, 40, 1000);
  kickB = new akAvBeat(kickF, 100, 200);
  sawB = new  akAvBeat(sawF,10, 100);
  
}


public void draw() {
  println(sec);
  sceneChange();
  SWOTCHING=SWOTCH%4;
  //SWOTCH++;
  //ED
  if(SWOTCHING == 1){
  pushMatrix();
  fft.forward(in.mix);
  //fill(0,0,0,40);
  //rect(-10,-10,width+10, width+10);
  translate(width/2, height/2);
  background(0);

  
  float ENV = envFol.getLastValues()[0] ;
 // if(ENV >1.) ENV =1.;
  
  float bassFft = fft.getAvg(1);
 // if (bassFft >90) bassFft =91.654;
      //first band, will get low end frequencies (kick, bass)
  float midFft = fft.getAvg(7)*10;
      //mid frequencies 
  float hiFft = fft.getAvg(5)*5;
      //higher frequencies 
  println(bassFft, midFft, hiFft);
  pushMatrix(); 
  
  
 
  hi.update(hiFft, ENV); 
  hi.display();
  
   fill(0);
  //fill(0,0,0,60);
  //strokeWeight(6);
 noStroke();
  //  black circle put beihind the bass object so its patterns dont mix too much with hi
  bass.update(bassFft, ENV); 
  ellipse(0, 0, bass.size*2, bass.size*2);
//  println(ENV, bassFft, frameRate);
  bass.display(); 

  pushMatrix();
  int t = 0;
  //for ( int t = 0; t < 360; t +=28) { 
     //make a ring of mid objects
  for ( int i = 0; i < mid.length; i ++) {
    float r = bass.size+mid[0].size;
    
    //convert polar coordinates to cartesian
    float x = r * cos(radians(t));
    float y = r * sin(radians(t));
    
    pushMatrix();
    translate(x, y);
  
    

      mid[i].update(midFft, ENV);
      mid[i].display();
   // }

    popMatrix();
    t+=45;
  }
  popMatrix();
  popMatrix();
  
  popMatrix();
  }else if (SWOTCHING == 0){
  //BECKY
  background(backR, backG, backB);

  beat.detect(in.mix);
  fftB.forward(in.mix);

  if (beat.isOnset() ) {
   changePat();
   }
   
   


  for (int i = 0; i < fftB.specSize(); i++)
  {
    

   
    // draw the line for frequency band i, scaling it up a bit so we can see it
    sum[i] += (fftB.getBand(i)-sum[i])*smoothScale;
    summed = sum[i]*10;
    midB = fftB.getFreq(i)*2;
  }
  
  

  if (midB > 24.5f) {
   changePat();
   stroke(r[0], g[0], b[0]);
   noFill();
   strokeWeight(2);
  }

    ellipse(width/2, height/2, midB*2, midB*2);






  //ellipse (width/2, height/2, val, val);
  pushMatrix();

  //scale(1.5);
  generate2(amp1[0], amp3[0], amp5[0], amp7[0], amp2[0], amp4[0], amp6[0], amp8[0], r[0], g[0], b[0], r3[0], g3[0], b3[0], r5[0], g5[0], b5[0], r2[0], g2[0], b2[0], r4[0], g4[0], b4[0]);


  popMatrix(); 
  } else if (SWOTCHING == 2){
 //SEB
 pushMatrix();
  audio.run();
  output.display();
  popMatrix();
 }
 
 //akhil
 else if (SWOTCHING == 3) {
   fftA.forward(in.mix);
  //these functions check if a beat has been triggered
  
  saw1B.check();

  beepB.check();

  clapB.check();

  kickB.check();

  sawB.check();

  // sets the height of the noise to 100 and reduces it if a kick is detected
  h =100+(255 -kickB.inc)*10;

  colorMode(RGB);
  background(0, beepB.inc/2, clapB.inc/2); //the g component of the color is set to 255 if a beep is detected and the b is set to 255 if a clap is detected

  pushMatrix();
  
  //moves the grid into the view
  scale(1, 1, -1);
  rotateX(2);
  translate(0, -965, -309);

  //creates the grid
  for (int i=0; i<dim; i++) {
    for (int j=0; j<dim; j++) {
      
      //calculates the next vertices
      int iN = (i+1);
      int jN = (j+1);
      
      //sets the b component of the stroke to its height relative to the z axis
      float c = map(noise(i*0.02f, (j+frameCount)*0.02f), 0, 1, 0, 255);
      
      //sets the r and b values of the stroke to 255 if a synth is heard
      stroke(saw1B.inc, saw1B.inc, c);
      
      //increases the stroke width if a different synth is heard
      strokeWeight(map(sawB.inc,1,255,1,10));
      
      noFill();
      beginShape();
      //creates a grid with y values corresponding to perlin noise. the y axis of the noise is constantly increased
      vertex(i*s, j*s, (h)*(noise(i*0.02f, (j+frameCount)*0.02f)-0.5f));
      vertex(iN*s, j*s, (h)*(noise(iN*0.02f, (j+frameCount)*0.02f)-0.5f));
      vertex(iN*s, jN*s, (h)*(noise(iN*0.02f, (jN+frameCount)*0.02f)-0.5f));
      vertex(i*s, jN*s, (h)*(noise(i*0.02f, (jN+frameCount)*0.02f)-0.5f));
      
      endShape();
    }
  }
  popMatrix();  
   
   
 }
}

public void generate2(int amp1, int amp2, int amp3, int amp4, int amp5, int amp6, int amp7, int amp8, int r, int g, int b, int r2, int g2, int b2, int r3, int g3, int b3, int r4, int g4, int b4, int r5, int g5, int b5) {


  pushMatrix();
  //magnify = 100;

  translate(width/2, height/2);

  for (int i = 0; i < co; i++) {
    /*
    pushMatrix();
     
     scale(1.75);
     rotate(angle);
     pattern2(i, amp4, amp1, r, g2, b5);
     popMatrix();
     */
    pushMatrix();

    scale(i/2);
    rotate(angle);
    pattern2(i, amp5, amp4, r5, g2, b5);
    popMatrix();


    pushMatrix();

    scale(2.5f);
    rotate(-angle);
    pattern2(i, amp5, amp1, r2, g3, b);
    popMatrix();

    pushMatrix();

    scale(1.5f);
    rotate(-angle);
    pattern2(i, amp1, amp4, r3, g, b5);
    popMatrix();


    pushMatrix();

    scale(2);
    rotate(-angle);
    pattern2(i, amp1, amp6, r3, g5, b4);
    popMatrix();

    pushMatrix();

    rotate(angle);
    pattern2(i, amp7, amp5, r2, g, b);
    popMatrix();


    pushMatrix();

    scale(3);
    rotate(-angle);
    pattern2(i, amp7, amp2, r5, g3, b);
    popMatrix();

    /*
    pushMatrix();
     scale(2.75);
     rotate(angle);
     pattern2(i, amp5, amp8, r, g5, b2);
     popMatrix();*/

    pushMatrix();

    scale(3.5f);
    rotate(-angle);
    pattern2(i, amp8, amp1, r5, g2, b4);
    popMatrix();

    pushMatrix();

    scale(4);
    rotate(angle);
    pattern2(i, amp4, amp8, r2, g5, b3);
    popMatrix();

    /*
    pushMatrix();
     scale(2.25);
     rotate(-angle);
     pattern2(i, amp6, amp4, r5, g3, b5);
     popMatrix();
    /*
     pushMatrix();
     scale(2.35);
     rotate(angle);
     pattern2(i, amp4, amp8, r, g4, b3);
     popMatrix();*/
  }

  popMatrix();

}





public void pattern2(int n, int amp, int amp2, int r, int g, int b) {




  for (int i = 1; i < elements; i++) {

    pushMatrix();

    noFill();
    noStroke();


    float summed1 = summed/50;
    
    float x = ((cos(spacing*i*amp*summed1)))/(sin(spacing*i*amp2/summed1))*magnify;
    float y = (sin(spacing*i*amp*summed1))/(sin(spacing*i*2*amp2*summed1))*magnify;

    fill(r, g, b, 235);
    ellipse(x, y, .9f, .9f);
    

    popMatrix();
  }
}

public void keyPressed() {
  
  if (key == 's') {
    SWOTCH++;
    SWOTCH = SWOTCH%4;
  }
}

public void changePat() {

  scaleX1 = PApplet.parseInt(random(-300, 300));
  scaleY1 = PApplet.parseInt(random(-100, 100));
  scaleX2 = PApplet.parseInt(random(-300, 300));
  scaleY2 = PApplet.parseInt(random(-100, 100));

  //    saveFrame("NEW7_####.png"); 


  backR = random(0, 50);
  backG = random(0, 50);
  backB = random(0, 50);

  for (int i = 0; i < co; i++) {


    amp1[i] = PApplet.parseInt(random(1, 40));
    amp2[i] = PApplet.parseInt(random(1, 40));
    r[i] = PApplet.parseInt(random(50, 255));
    g[i] = PApplet.parseInt(random(50, 255));
    b[i] = PApplet.parseInt(random(50, 255));



    amp3[i] = PApplet.parseInt(random(1, 40));
    amp4[i] = PApplet.parseInt(random(1, 40));
    r2[i] = PApplet.parseInt(random(50, 255));
    g2[i] = PApplet.parseInt(random(50, 255));
    b2[i] = PApplet.parseInt(random(50, 255));

    amp5[i] = PApplet.parseInt(random(1, 40));
    amp6[i] = PApplet.parseInt(random(1, 40));
    r3[i] = PApplet.parseInt(random(50, 255));
    g3[i] = PApplet.parseInt(random(50, 255));
    b3[i] = PApplet.parseInt(random(50, 255));


    amp7[i] = PApplet.parseInt(random(1, 40));
    amp8[i] = PApplet.parseInt(random(1, 40));
    r4[i] = PApplet.parseInt(random(50, 255));
    g4[i] = PApplet.parseInt(random(50, 255));
    b4[i] = PApplet.parseInt(random(50, 255));


    amp9[i] = PApplet.parseInt(random(1, 40));
    amp10[i] = PApplet.parseInt(random(1, 40));
    r5[i] = PApplet.parseInt(random(50, 255));
    g5[i] = PApplet.parseInt(random(50, 255));
    b5[i] = PApplet.parseInt(random(50, 255));
  }
}
int timer=0;
int milli;
int sec=20;
public void sceneChange(){
  milli=sec*1000;
  if (millis()-timer>milli){
    timer=millis();
    SWOTCH=(int)random(0, 3);
    sec=(int)random(10, 35);
  }
  
}
class Audio {
  float amp;
  float level;
  float maxLevel=40;
  PVector pulseVector;
  float pulseRadius=0;
  float speed = 50;



  Audio() {
  }
  
  public void run() {
    analysis();
    pulse();
  }

  public void analysis() {
    amp = map(envFollow.getLastValues()[0], 0, 1, 0.2f, 1 ); //mapping amplitude with a minimum value of 0.2
    level = amp*200; //setting level to amp*200 so that it ranges from values 40 through 200
    if (level>=maxLevel && pulseRadius>=800) {
      maxLevel=level+10; //level is the amplitude value of the small white particles and maxR is their maximum value
      pulseRadius=maxLevel;
      speed=50;
    }
  }
  
  //function to create a circular pulse that spreads out from the center approximately matching the beat of the song
  public void pulse() {
    if (pulseRadius<1000)
      pulseRadius+=speed;

    speed+=0.4f*amp; //pulse accelerates out

    if (maxLevel>level) {
      maxLevel--; //we constantly decrease maxLevel's value so that it's always pushed fowards by level
      stroke(140, 200, 255);
      strokeWeight(10);
      noFill();
      beginShape();
      for (int i=0; i<360; i+=1) {
        float a = radians(i);
        pulseVector = new PVector(pulseRadius*cos(a)+width/2, pulseRadius*sin(a)+height/2, (output.ln(pulseRadius)*200)-1000);
        vertex(pulseVector.x, pulseVector.y, pulseVector.z );
      }
      endShape(CLOSE);
      //cameraChange();
    }
  }
}


/*
My project is an audio visual particle system that uses an arraylist of particles within an arraylist of particle systems to create a natural dynamic of particle
movement and aesthetic that is also determined by tracking the amplitude of a chosen song. The direction of the particle systems creates a vortex look where
all white particles accelerate inwards towards the center in a circular motion on the x and y axis and a motion that is determined by the natural logarithmic value
of it's radius on the z axis. For each of these white particles there is also a coloured particle with the same x and y position but with the inverse of the logarithmic
Z value to create a dome like shape where the two particle systems meet in the center. by using an envelope follower, the amplitude of the song at any given time
determines the uniform speed at which each particle moves as well as the brightness of the particles and the strokeWeight of half the particles (where the other half
stays in a uniform stroke weight). There is also a pulse effect that shoots out a blue ring from the center whenever the amplitude of the song reaches a distinctly
high value, usually on a kick drum hit which causes the blue pulse to approximately match the rhythm & beat of the song. With this same event, there is also a 10% chance
that the camera will change perspective to a new angle and direction which simulates the aesthetic of a music video where the camera cuts match the rhythm of the song.
*/
//https://forum.processing.org/two/discussion/7172/echo-effect-with-minim

class MyAudioSocket extends UGen implements AudioListener
{
 
  private float[] left;
  private float[] right;
  private int buffer_max;
  private int inpos, outpos;
  private int count;
 
  MyAudioSocket(int buffer_size)
  {
     int n_buffers = 4;
     buffer_max = n_buffers * buffer_size;
     left = new float[buffer_max];
     right = new float[buffer_max];
     inpos = 0;
     outpos = 0;
     count = 0;
  }
 
  // The AudioListener:samples method accepts new input samples
  public synchronized void samples(float[] samp)
  {
    // handle mono by writing samples to both left and right
    samples(samp, samp);
  }
 
  public synchronized void samples(float[] sampL, float[] sampR)
  {
    System.arraycopy(sampL, 0, left, inpos, sampL.length);
    System.arraycopy(sampR, 0, right, inpos, sampR.length);
    inpos += sampL.length;
    if (inpos == buffer_max) {
      inpos = 0;
    }
    count += sampL.length;
 
  }
 
 
  //if I understand this correctly, UGens operate on a per sample basis
 // override
  protected void uGenerate(float[] channels) 
  {
    if (count > 0) {
      for(int n = 0; n <channels.length; n++){
       channels[n] = ((n&1) == 0)?left[outpos]:right[outpos]; 
      }
      outpos++;
      if (outpos == buffer_max) {
         outpos = 0;
       }
      count--;
    }
 
  }
 
}

class Output {
  String filename; //string for the filepath of our selected song

  

  //used to control the camera within our 3D space
  float camx;
  float camy;
  float camz;

  //initialising audio object

  //used to control the direction of our camera's movement
  int moveX=(int)random(0, 1);
  int moveY=(int)random(0, 1);
  
  AudioOutput out;

  
  ArrayList<ParticleSystem> systems; //Initialising ArrayList of particle systems
  
  Output() {

  }

  public void initialise() {
    filename="Promesses.mp3";
    camx=960;
    camy=540; 
    systems = new ArrayList<ParticleSystem>();
    systems.add(new ParticleSystem());
  }
  
  public void display () {
    background(0);
    camera(camx, camy, ((height/2.0f) / tan(PI*60.0f / 360.0f)), width/2, height/2, 0, 0, 1, 0);
    
    for (ParticleSystem ps : systems) {
      ps.run();
      ps.addParticle();
    }
    cameraMove();
  }


  public void cameraChange() {
    float r=random(1);
    if (r<0.1f) { //10% chance to change camera when this is called
      moveX=(int)random(0, 1);
      moveY=(int)random(0, 1);
      if (r<0.02f) {
        camx=random(160, 1800);
        camy=random(40, 1480);
      }
    }
  }

  public float ln(float x) {
    return (log(x) / log(exp(1)));
  }

  //void fileSelected(File selection) {
  //  if (selection == null) {
  //    println("Window was closed or the user hit cancel.");
  //  } else {
  //    println("User selected " + selection.getAbsolutePath());
  //    filename = selection.getAbsolutePath();
  //  }
  //}

  //void stopLoop() {
  //  while (filename == null) {
  //    noLoop();
  //  }
  //  loop();
  // }

  public void cameraMove() {
    if (moveX == 0) {
      if (camx<=1800) {
        camx+=5;
      } else {
        moveX=1;
      }
    }
    if (moveX == 1) {
      if (camx>=160) {
        camx-=5;
      } else {
        moveX=0;
      }
    }

    if (moveY == 0) {
      if (camy<=1480) {
        camy+=5;
      } else {
        moveY=1;
      }
    }
    if (moveY == 1) {
      if (camy>=40) {
        camy-=5;
      } else {
        moveY=0;
      }
    }
  }
}
class Particle {


  float size;
  float spread;
  float theta;
  float alpha;
  int rotD;
  int c;
  float posV;


  Particle(float size_, int rotD_) {

    size = size_/2;
    spread = height/ 500;
    rotD = rotD_;
    
  }

  public void display() {
    pushMatrix();
    for (int i = 0; i < size; i +=2) {      
      for ( int j = 0; j < size; j +=2) {

        stroke(c, alpha);
           //colour adnd aplpha value defined according to fft 
       
        strokeWeight(5);
                  
        rotate(radians(theta)*rotD);
          //each point is rotated further than the last by an amount set by fft  
          // rotD is used when the object is defined to make set the direction of rotation, (1 for clockwise, -1 for anti)
       float displacer = map(noise(posV),0,1,-posV,posV);
          //used to displace praticles slightly aaccording to volume. the lower the amplitude the more sparse hte particles
        point(i * spread * displacer, j * spread * displacer  );       
      }
    }
     popMatrix();
  }
  
  public void update(float fft, float env){
   
    theta = findTheta( fft );
    alpha = findAlpha(  fft );
   // println(alpha);
    c = findColour( fft );
   // posV = findPosV (env);
    posV = 10-(env*10);
  
  }
  
  public float findTheta( float x){
   float theta_ = map(x, 0, 400, 0, 360);   
    return theta_;
  }
  
  public float findAlpha( float x){
  float alpha_ = map(x, 0, 400, 20, 255);
  return alpha_;
  }
  
  public int findColour( float x){
    float r = map(noise(x), 0, 1, 50, 180);
    float g = map(noise(x*100), 0, 1, 50, 180);
    float b = map(noise(x*325), 0, 1, 50, 180);
    int c_ = color(r, g, b);
    return c_;
    
  }
  
  public float findPosV( float x ){
   
    float posV_ = map(x, 0, 1, 10, 0);
    return posV_;
  }   
}
class ParticleSystem {
  ArrayList<Particles> particles; //arraylist of all the particles within a single particle system

  ParticleSystem() {
   particles = new ArrayList<Particles>();
  }

  public void run() {
    for (int i = particles.size()-1; i >= 0; i--) {
      Particles p = particles.get(i);
      p.run();
      if (p.isDead()) {
        particles.remove(i);
      }
    }
  }

  public void addParticle() {
    for (int i =0; i<30; i++) {
      particles.add(new Particles(1000, 0.001f, random(0, PI*2)));
    }
  }
}
class Particles {
  float radius;
  float frequency;
  PVector velocity;
  float angle;
  float speed=0;
  float z;
  float lifespan=255;
  float col;
  float audioVis;

  Particles(float r, float f, float l) {
    radius = r;
    frequency =f;
    angle = l;
  }

  public void run() {
    update();
    display();
  }

  public void update() {
    velocity = new PVector(cos(angle)*audioVis+width/2, sin(angle)*audioVis+height/2, (output.ln(radius)*200)-1000);
    audioVis = radius+audio.level;
    //audioVelocity = new PVector(cos(angle)*audioVis+width/2, sin(angle)*audioVis+height/2);
    float col=frequency*audio.level;
    angle=angle+col;
    speed+=0.1f;
    radius-=speed;
  }

  public boolean isDead() {
    if (radius<=audio.level) {
      return true;
    } else {
      return false;
    }
  }

  public void display() {
    float r=random(1);
    stroke(audio.amp*255);
    if (r<0.5f)
      strokeWeight(audio.amp*10);

    else
      strokeWeight(4);

    point(velocity.x, velocity.y, velocity.z);
    stroke(audio.amp*150, (frameCount%255), audio.amp*255);
    point(velocity.x, velocity.y, velocity.z-(radius*0.5f));
  }
}


class akAv {

  FFT fft;
  
  //important frequencies of various instruments in song
float beepF = 1162.793f;
float clapF = 1874.9219f;
float kickF = 129.19922f;
float sawF = 2024.1211f;
float snareF = 9087.012f;
float breathF = 2885.4492f;
float saw1F = 516.797f;

//beat objects that detect if amplitude of a certain band is above a threshhold 
akAvBeat beepB;
akAvBeat clapB;
akAvBeat saw1B;
akAvBeat kickB;
akAvBeat sawB;


//drawing objects
float c = 0;

int dim = 100; //the dimensions of the grid
int s = 1680/dim; //the size of each square in grid
float h = 0; //the multiplier for the noise 




akAv() {
  
   //fft = new FFT(song.bufferSize(), song.sampleRate());
  noStroke();
  
  //initalizing all the objects to detect various instruments in song
  beepB = new akAvBeat(beepF, 40, 500); 
  clapB = new akAvBeat(clapF, 5, 10);
  saw1B = new akAvBeat(saw1F, 40, 1000);
  kickB = new akAvBeat(kickF, 100, 200);
  sawB = new akAvBeat(sawF,10, 100);
  
  
}



public void akAvDraw() {
  
   
  //these functions check if a beat has been triggered
  
  saw1B.check();

  beepB.check();

  clapB.check();

  kickB.check();

  sawB.check();

  // sets the height of the noise to 100 and reduces it if a kick is detected
  h =100+(255 -kickB.inc)*10;

  colorMode(RGB);
  background(0, beepB.inc/2, clapB.inc/2); //the g component of the color is set to 255 if a beep is detected and the b is set to 255 if a clap is detected

  pushMatrix();
  
  //moves the grid into the view
  scale(1, 1, -1);
  rotateX(2);
  translate(0, -965, -309);

  //creates the grid
  for (int i=0; i<dim; i++) {
    for (int j=0; j<dim; j++) {
      
      //calculates the next vertices
      int iN = (i+1);
      int jN = (j+1);
      
      //sets the b component of the stroke to its height relative to the z axis
      float c = map(noise(i*0.02f, (j+frameCount)*0.02f), 0, 1, 0, 255);
      
      //sets the r and b values of the stroke to 255 if a synth is heard
      stroke(saw1B.inc, saw1B.inc, c);
      
      //increases the stroke width if a different synth is heard
      strokeWeight(map(sawB.inc,1,255,1,10));
      
      noFill();
      beginShape();
      //creates a grid with y values corresponding to perlin noise. the y axis of the noise is constantly increased
      vertex(i*s, j*s, (h)*(noise(i*0.02f, (j+frameCount)*0.02f)-0.5f));
      vertex(iN*s, j*s, (h)*(noise(iN*0.02f, (j+frameCount)*0.02f)-0.5f));
      vertex(iN*s, jN*s, (h)*(noise(iN*0.02f, (jN+frameCount)*0.02f)-0.5f));
      vertex(i*s, jN*s, (h)*(noise(i*0.02f, (jN+frameCount)*0.02f)-0.5f));
      
      endShape();
    }
  }
  popMatrix();  
  
}




}
class akAvBeat {

  float freq; //the frequency to check at
  float thresh; //the threshold after which a beat is detected
  float timeOfLast = 0; //time of the last beat detected
  float timeSinceLast = 0; //time since the last beat detectd
  float timeThresh; //threshold of how long between beats are allowed to be detected
  float speed = 0.8f; //speed of increase and decrease of the inc value

  float inc=0; //inc value is set to maximum if a beat is detected and slowly decreses based on speed
  float maxInc=255;
  boolean beatOn = false; //boolean for if beat is detected

  akAvBeat(float f, float th, float tith) {

    freq = f;
    thresh = th;
    timeThresh = tith;
  }

  public void check() {

    if ((fftA.getFreq(freq)>thresh)&&(timeSinceLast>timeThresh)) { //checks if the amplitude of the frequency to be checked is above the threshold and it has been enough time since the last beat
      beatOn = true;
      timeOfLast = millis();
    } else { //at all time beatOn is false and the time since the last beat is recorded
      beatOn = false;
      timeSinceLast = millis()-timeOfLast;
    }

    if (beatOn == true) { //if beatOn is true, sets the inc to the maxInc

      inc = maxInc;
    }
    if (inc>1) { // inc is constantly decreased by speed until it is equal to 1

      inc *=speed;
    }else{inc = 1;}
  }
}
  public void settings() {  fullScreen(P3D);  smooth(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "bigBOI" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
